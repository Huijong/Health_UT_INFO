import os
import json
import time
from datetime import datetime
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

# 1. 기본 설정
SCOPES = ['https://www.googleapis.com/auth/gmail.readonly']
CLIENT_SECRET_FILE = r'C:\Users\Pro16\PycharmProjects\PythonProject\client_secret_418646364904-8s4nca5pquauri5rpg7gv0f5rllkcrtu.apps.googleusercontent.com.json'
TOKEN_FILE = 'token.json'
SAVE_FILE_PATH = 'emails_archive.json'  # 메일이 저장될 로컬 JSON 파일
CHECK_INTERVAL = 60  # 새 메일 체크 주기 (단위: 초, 60초 = 1분)


def get_gmail_service():
    """Gmail API 인증 및 서비스 객체 생성"""
    creds = None
    if os.path.exists(TOKEN_FILE):
        creds = Credentials.from_authorized_user_file(TOKEN_FILE, SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(CLIENT_SECRET_FILE, SCOPES)
            creds = flow.run_local_server(port=0)
        with open(TOKEN_FILE, 'w') as token:
            token.write(creds.to_json())
    return build('gmail', 'v1', credentials=creds)


def load_local_emails():
    """이미 저장된 로컬 JSON 파일 불러오기"""
    if os.path.exists(SAVE_FILE_PATH):
        try:
            with open(SAVE_FILE_PATH, 'r', encoding='utf-8') as f:
                return json.load(f)
        except json.JSONDecodeError:
            return {}
    return {}


def save_local_emails(data):
    """메일 데이터를 로컬 JSON 파일에 저장"""
    with open(SAVE_FILE_PATH, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)


def fetch_new_emails(service, last_check_time):
    """마지막 체크 시간 이후로 온 새 메일 가져오기"""
    # Gmail 쿼리문 (예: after:1719500000 -> 특정 타임스탬프 이후의 메일 검색)
    query = f"after:{int(last_check_time)}"

    try:
        results = service.users().messages().list(userId='me', q=query).execute()
        messages = results.get('messages', [])
        return messages
    except Exception as e:
        print(f"메일 목록을 가져오는 중 오류 발생: {e}")
        return []


def parse_and_save_message(service, message_id, local_data):
    """메일 ID로 상세 정보를 파싱해 로컬 데이터 딕셔너리에 추가"""
    if message_id in local_data:
        return False  # 이미 저장된 메일은 패스

    try:
        msg = service.users().messages().get(userId='me', id=message_id).execute()
        payload = msg.get('payload', {})
        headers = payload.get('headers', [])

        # 헤더에서 필요한 정보 추출
        subject = next((h['value'] for h in headers if h['name'].lower() == 'subject'), '제목 없음')
        sender = next((h['value'] for h in headers if h['name'].lower() == 'from'), '발신자 없음')
        date = next((h['value'] for h in headers if h['name'].lower() == 'date'), '날짜 없음')

        # 저장할 데이터 구조화
        local_data[message_id] = {
            "fetched_at": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            "from": sender,
            "subject": subject,
            "date": date,
            "snippet": msg.get('snippet', '')
        }
        print(f" Saved: {subject}")
        return True
    except Exception as e:
        print(f"메일 상세 정보 가져오기 실패 (ID: {message_id}): {e}")
        return False


def main():
    service = get_gmail_service()
    print("Gmail 모니터링을 시작합니다...")

    # 프로그램 시작 시점을 기준점으로 잡음 (혹은 원하는 과거 타임스탬프 설정 가능)
    last_check_time = time.time()

    while True:
        print(f"\n[{datetime.now().strftime('%H:%M:%S')}] 새 메일 확인 중...")

        # 1. 새 메일 목록 조회
        new_messages = fetch_new_emails(service, last_check_time)

        if new_messages:
            # 2. 기존 저장된 파일 로드
            local_data = load_local_emails()
            updated = False

            # 3. 새 메일 하나씩 상세 정보 파싱 후 추가
            for msg_item in new_messages:
                msg_id = msg_item['id']
                if parse_and_save_message(service, msg_id, local_data):
                    updated = True

            # 4. 변경사항이 있으면 파일 저장
            if updated:
                save_local_emails(local_data)
                print(f"-> {SAVE_FILE_PATH} 업데이트 완료!")
        else:
            print("-> 새로 도착한 메일이 없습니다.")

        # 마지막 체크 시간 업데이트 (체크 직전 시간으로 세팅하여 공백 방지)
        last_check_time = time.time()

        # 대기
        time.sleep(CHECK_INTERVAL)


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n프로그램을 종료합니다.")